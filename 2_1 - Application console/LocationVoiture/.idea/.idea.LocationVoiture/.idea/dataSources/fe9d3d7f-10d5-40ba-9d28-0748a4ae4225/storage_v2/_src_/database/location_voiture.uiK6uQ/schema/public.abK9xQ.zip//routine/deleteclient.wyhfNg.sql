create function deleteclient(client_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM client WHERE id = client_id;
END;
$$;

alter function deleteclient(integer) owner to postgres;

