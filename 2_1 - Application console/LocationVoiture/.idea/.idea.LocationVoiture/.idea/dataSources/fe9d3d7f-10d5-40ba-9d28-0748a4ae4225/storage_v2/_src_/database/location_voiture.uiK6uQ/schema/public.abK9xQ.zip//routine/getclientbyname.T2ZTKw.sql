create function getclientbyname(given_name text) returns SETOF client
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT *
    FROM client
    WHERE last_name = given_name;
END;
$$;

alter function getclientbyname(text) owner to postgres;

