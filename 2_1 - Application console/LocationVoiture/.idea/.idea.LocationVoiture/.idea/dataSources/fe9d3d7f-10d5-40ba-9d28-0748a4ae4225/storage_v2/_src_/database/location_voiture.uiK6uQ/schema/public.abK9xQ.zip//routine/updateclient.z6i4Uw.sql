create function updateclient(client_id integer, last_name text, first_name text, email text, street text, postal_code text, city text, country text, driving_license text, birth_date date) returns integer
    language plpgsql
as
$$
BEGIN
    UPDATE client
    SET
        last_name = last_name,
        first_name = first_name,
        email = email,
        address = ROW(street, postal_code, city, country),
        driving_license = driving_license,
        birth_date = birth_date
    WHERE id = client_id;

    RETURN client_id;
END;
$$;

alter function updateclient(integer, text, text, text, text, text, text, text, text, date) owner to postgres;

