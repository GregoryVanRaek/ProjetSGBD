create function getallclients() returns SETOF client
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT *
    FROM client
    ORDER BY last_name;
END;
$$;

alter function getallclients() owner to postgres;

