create function createclient(last_name text, first_name text, email text, street text, postal_code text, city text, country text, driving_license text, birth_date date) returns integer
    language plpgsql
as
$$
DECLARE
    inserted_id INT;
BEGIN
    INSERT INTO client (last_name, first_name, email, address, driving_license, birth_date)
    VALUES (last_name, first_name, email, ROW(street, postal_code, city, country), driving_license, birth_date)
    RETURNING id INTO inserted_id;

    RETURN inserted_id;
END;
$$;

alter function createclient(text, text, text, text, text, text, text, text, date) owner to postgres;

