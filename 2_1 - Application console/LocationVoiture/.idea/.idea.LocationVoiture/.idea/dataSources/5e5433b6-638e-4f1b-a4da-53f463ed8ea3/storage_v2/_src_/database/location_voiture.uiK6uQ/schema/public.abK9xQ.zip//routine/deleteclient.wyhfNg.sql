create function deleteclient(client_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    DELETE FROM client
    WHERE id = client_id;

    RETURN FOUND;
END;
$$;

alter function deleteclient(integer) owner to postgres;

