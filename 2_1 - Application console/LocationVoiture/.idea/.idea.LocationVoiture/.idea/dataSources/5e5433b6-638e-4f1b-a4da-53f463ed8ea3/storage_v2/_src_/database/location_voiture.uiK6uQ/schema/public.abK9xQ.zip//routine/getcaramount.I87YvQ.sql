create function getcaramount(car_id integer) returns numeric
    language plpgsql
as
$$
DECLARE
    daily_rate NUMERIC;
BEGIN
    SELECT cat.daily_rate
    INTO daily_rate
    FROM car c
    JOIN model m ON c.model_id = m.id
    JOIN category cat ON m.category_id = cat.id
    WHERE c.id = $1;

    RETURN daily_rate;
END;
$$;

alter function getcaramount(integer) owner to postgres;

