create function createcategory(category_name character varying, category_daily_rate numeric) returns integer
    language plpgsql
as
$$
DECLARE
    new_id INT;
BEGIN
    INSERT INTO category(name, daily_rate)
    VALUES($1, $2)
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function createcategory(varchar, numeric) owner to postgres;

