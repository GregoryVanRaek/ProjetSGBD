create function getallparkingcodes(only_available boolean)
    returns TABLE(id integer, code character)
    language plpgsql
as
$$
BEGIN
    IF $1 THEN
        RETURN QUERY
        SELECT p.id, p.code
        FROM parking p
        WHERE p.id NOT IN (SELECT car.parking_id FROM car WHERE car.parking_id IS NOT NULL);
    ELSE
        RETURN QUERY
        SELECT p.id, p.code
        FROM parking p;
    END IF;
END;
$$;

alter function getallparkingcodes(boolean) owner to postgres;

