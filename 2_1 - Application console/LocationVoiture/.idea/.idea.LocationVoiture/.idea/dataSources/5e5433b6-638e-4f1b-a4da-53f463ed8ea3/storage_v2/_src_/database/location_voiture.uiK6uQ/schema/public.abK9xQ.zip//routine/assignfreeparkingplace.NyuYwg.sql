create function assignfreeparkingplace(car_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    free_parking_id INT;
BEGIN
    SELECT p.id
    INTO free_parking_id
    FROM parking p
    WHERE p.id NOT IN (SELECT c.parking_id FROM car c WHERE c.parking_id IS NOT NULL)
    LIMIT 1;

    IF free_parking_id IS NOT NULL THEN
        UPDATE car
        SET parking_id = free_parking_id
        WHERE id = $1;

        RETURN TRUE;
    END IF;

    RETURN FALSE;
END;
$$;

alter function assignfreeparkingplace(integer) owner to postgres;

