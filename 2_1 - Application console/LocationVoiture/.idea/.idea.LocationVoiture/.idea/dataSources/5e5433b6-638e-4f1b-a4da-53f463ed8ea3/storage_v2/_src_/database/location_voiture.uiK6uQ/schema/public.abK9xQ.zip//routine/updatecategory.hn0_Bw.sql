create function updatecategory(category_id integer, category_name character varying, category_daily_rate numeric) returns boolean
    language plpgsql
as
$$
BEGIN
    UPDATE category
    SET name = $2,
        daily_rate = $3
    WHERE id = $1;

    RETURN FOUND;
END;
$$;

alter function updatecategory(integer, varchar, numeric) owner to postgres;

