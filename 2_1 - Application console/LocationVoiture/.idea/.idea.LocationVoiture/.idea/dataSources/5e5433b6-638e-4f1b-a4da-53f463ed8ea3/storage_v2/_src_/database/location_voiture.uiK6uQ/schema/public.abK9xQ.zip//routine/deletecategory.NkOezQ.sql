create function deletecategory(category_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    DELETE FROM category WHERE id = $1;
    RETURN FOUND;
END;
$$;

alter function deletecategory(integer) owner to postgres;

