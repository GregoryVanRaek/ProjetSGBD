create function deletecar(car_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM car
    WHERE id = $1;
END;
$$;

alter function deletecar(integer) owner to postgres;

