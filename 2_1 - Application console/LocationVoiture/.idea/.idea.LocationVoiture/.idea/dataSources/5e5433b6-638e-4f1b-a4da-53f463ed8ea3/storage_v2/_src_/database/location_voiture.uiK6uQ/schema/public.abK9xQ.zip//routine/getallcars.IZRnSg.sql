create function getallcars(only_available boolean)
    returns TABLE(id integer, license_plate character varying, color character varying, parking_code character, model_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            c.id,
            c.license_plate::VARCHAR,
            c.color::VARCHAR,
            p.code::CHAR(3),
            m.name::VARCHAR as model_name
        FROM car c
        LEFT JOIN parking p ON c.parking_id = p.id
        LEFT JOIN model m ON c.model_id = m.id
        WHERE only_available IS FALSE OR c.parking_id IS NOT NULL;
END;
$$;

alter function getallcars(boolean) owner to postgres;

