create function getclientbyid(client_id integer)
    returns TABLE(id integer, first_name character varying, last_name character varying, email character varying, street character varying, postal_code character varying, city character varying, country character varying, driving_license character varying, birth_date date)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT c.id, c.last_name, c.first_name, c.email,
           (address).street AS street,
           (address).postal_code AS postal_code,
           (address).city AS city,
           (address).country AS country,
           c.driving_license, c.birth_date
    FROM client c
    WHERE c.id = client_id;
END;
$$;

alter function getclientbyid(integer) owner to postgres;

