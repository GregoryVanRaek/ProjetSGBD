create function getallmodels()
    returns TABLE(id integer, name character varying, brand character varying, seat_number integer, category_id integer, category_name character varying, daily_rate numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        m.id,
        m.name,
        m.brand,
        m.seat_number,
        m.category_id,
        c.name as category_name,
        c.daily_rate
    FROM model m
    LEFT JOIN category c ON m.category_id = c.id;
END;
$$;

alter function getallmodels() owner to postgres;

