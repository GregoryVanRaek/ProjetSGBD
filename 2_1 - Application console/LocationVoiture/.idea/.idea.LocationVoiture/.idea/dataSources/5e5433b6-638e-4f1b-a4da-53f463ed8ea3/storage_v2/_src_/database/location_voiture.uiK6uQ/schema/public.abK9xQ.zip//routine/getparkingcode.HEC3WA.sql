create function getparkingcode(parking_code integer)
    returns TABLE(id integer, code character)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT p.id, p.code
    FROM parking p
    WHERE p.id = $1;
END;
$$;

alter function getparkingcode(integer) owner to postgres;

