create function getallcategories()
    returns TABLE(id integer, name character varying, daily_rate numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT c.id, c.name, c.daily_rate
    FROM category c
    ORDER BY c.id;
END;
$$;

alter function getallcategories() owner to postgres;

