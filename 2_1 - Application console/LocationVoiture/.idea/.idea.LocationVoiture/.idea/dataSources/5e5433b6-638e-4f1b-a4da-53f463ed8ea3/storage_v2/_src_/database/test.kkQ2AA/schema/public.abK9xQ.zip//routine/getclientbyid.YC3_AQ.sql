create function getclientbyid(given_id integer) returns SETOF client
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT *
    FROM client
    WHERE id = given_id;
END;
$$;

alter function getclientbyid(integer) owner to postgres;

