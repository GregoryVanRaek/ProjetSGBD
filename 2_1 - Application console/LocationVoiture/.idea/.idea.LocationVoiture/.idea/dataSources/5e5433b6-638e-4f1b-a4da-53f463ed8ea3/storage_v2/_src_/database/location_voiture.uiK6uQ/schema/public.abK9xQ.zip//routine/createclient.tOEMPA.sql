create function createclient(last_name character varying, first_name character varying, email character varying, street character varying, postal_code character varying, city character varying, country character varying, driving_license character varying, birth_date timestamp without time zone) returns integer
    language plpgsql
as
$$
DECLARE
    new_id INT;
BEGIN
    INSERT INTO CLIENT(
        last_name,
        first_name,
        email,
        address,
        driving_license,
        birth_date
    )
    VALUES(
        $1,
        $2,
        $3,
        ROW(street, postal_code, city, country),
        $8,
        $9::DATE  -- conversion explicite en DATE si nécessaire
    )
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function createclient(varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, timestamp) owner to postgres;

