create function createcar(license_plate character varying, color character varying, parking_id integer, model_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    new_car_id INT;
BEGIN
    INSERT INTO car (license_plate, color, parking_id, model_id)
    VALUES ($1, $2, $3, $4)
    RETURNING id INTO new_car_id;

    RETURN new_car_id;
END;
$$;

alter function createcar(varchar, varchar, integer, integer) owner to postgres;

