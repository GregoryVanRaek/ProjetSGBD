create function getallrentals(with_completed_and_cancelled boolean)
    returns TABLE(id integer, car_id integer, client_id integer, start_date date, duration integer, amount numeric, status character varying, license_plate character varying, client_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT r.id, r.car_id, r.client_id, r.start_date, r.duration, r.amount, r.status,
           c.license_plate, cl.last_name AS client_name
    FROM rental r
    LEFT JOIN car c ON r.car_id = c.id
    LEFT JOIN client cl ON r.client_id = cl.id
    WHERE with_completed_and_cancelled OR r.status IN ('rent', 'reserved')
    ORDER BY r.start_date, r.status;
END;
$$;

alter function getallrentals(boolean) owner to postgres;

