create function createmodel(model_name character varying, model_brand character varying, model_seat_number integer, model_category_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    new_id INT;
BEGIN
    INSERT INTO model(name, brand, seat_number, category_id)
    VALUES(model_name, model_brand, model_seat_number, model_category_id)
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function createmodel(varchar, varchar, integer, integer) owner to postgres;

