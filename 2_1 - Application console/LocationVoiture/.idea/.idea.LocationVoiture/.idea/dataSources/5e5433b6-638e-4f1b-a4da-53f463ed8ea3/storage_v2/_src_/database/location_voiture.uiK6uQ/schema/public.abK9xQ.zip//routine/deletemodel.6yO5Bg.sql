create function deletemodel(model_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    DELETE FROM model WHERE id = model_id;
    RETURN FOUND;
END;
$$;

alter function deletemodel(integer) owner to postgres;

