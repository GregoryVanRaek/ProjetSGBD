create function createrental(car_id integer, client_id integer, start_date timestamp without time zone, duration integer, amount numeric, status character varying) returns integer
    language plpgsql
as
$$
DECLARE
    new_id INT;
BEGIN
    INSERT INTO rental (car_id, client_id, start_date, duration, amount, status)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function createrental(integer, integer, timestamp, integer, numeric, varchar) owner to postgres;

