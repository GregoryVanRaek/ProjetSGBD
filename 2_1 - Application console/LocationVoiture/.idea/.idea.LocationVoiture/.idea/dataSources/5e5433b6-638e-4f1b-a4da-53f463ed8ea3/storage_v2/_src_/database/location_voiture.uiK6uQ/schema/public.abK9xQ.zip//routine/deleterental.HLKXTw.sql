create function deleterental(rental_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    DELETE FROM rental
    WHERE id = rental_id;

    RETURN FOUND;
END;
$$;

alter function deleterental(integer) owner to postgres;

