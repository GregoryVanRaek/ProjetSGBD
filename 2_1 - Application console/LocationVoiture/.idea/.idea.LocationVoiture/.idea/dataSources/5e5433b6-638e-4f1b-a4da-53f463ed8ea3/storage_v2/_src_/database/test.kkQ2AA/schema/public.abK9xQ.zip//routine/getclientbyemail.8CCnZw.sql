create function getclientbyemail(given_email text) returns SETOF client
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT *
    FROM client
    WHERE email = given_email;
END;
$$;

alter function getclientbyemail(text) owner to postgres;

