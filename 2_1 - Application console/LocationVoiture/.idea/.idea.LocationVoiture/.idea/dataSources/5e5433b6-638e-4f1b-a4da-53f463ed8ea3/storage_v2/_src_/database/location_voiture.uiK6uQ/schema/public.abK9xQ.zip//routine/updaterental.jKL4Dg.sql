create function updaterental(rental_id integer, car_id integer, client_id integer, start_date timestamp without time zone, duration integer, amount numeric, status character varying) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE rental
    SET car_id = $2, client_id = $3, start_date = $4, duration = $5, amount = $6, status = $7
    WHERE id = $1;
END;
$$;

alter function updaterental(integer, integer, integer, timestamp, integer, numeric, varchar) owner to postgres;

