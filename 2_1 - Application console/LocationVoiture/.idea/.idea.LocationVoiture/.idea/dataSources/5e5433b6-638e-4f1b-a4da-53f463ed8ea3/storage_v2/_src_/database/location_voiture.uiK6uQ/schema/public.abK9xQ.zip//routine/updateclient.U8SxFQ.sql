create function updateclient(client_id integer, last_name character varying, first_name character varying, email character varying, street character varying, postal_code character varying, city character varying, country character varying, driving_license character varying, birth_date timestamp without time zone) returns boolean
    language plpgsql
as
$$
BEGIN
    UPDATE client
    SET
        last_name = $2,
        first_name = $3,
        email = $4,
        address = ROW($5, $6, $7, $8),
        driving_license = $9,
        birth_date = $10::DATE
    WHERE id = client_id;

    RETURN FOUND;
END;
$$;

alter function updateclient(integer, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, timestamp) owner to postgres;

