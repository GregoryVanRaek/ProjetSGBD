create function updateparking(car_id integer, parking_id integer) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE car
    SET parking_id = $2
    WHERE id = $1;
END;
$$;

alter function updateparking(integer, integer) owner to postgres;

