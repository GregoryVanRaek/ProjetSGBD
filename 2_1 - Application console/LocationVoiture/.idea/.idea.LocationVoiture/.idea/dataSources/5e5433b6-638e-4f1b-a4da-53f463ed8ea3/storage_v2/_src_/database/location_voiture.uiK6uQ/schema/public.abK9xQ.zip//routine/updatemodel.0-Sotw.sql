create function updatemodel(model_id integer, model_name character varying, model_brand character varying, model_seat_number integer, model_category_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    UPDATE model
    SET
        name = model_name,
        brand = model_brand,
        seat_number = model_seat_number,
        category_id = model_category_id
    WHERE id = model_id;

    RETURN FOUND;
END;
$$;

alter function updatemodel(integer, varchar, varchar, integer, integer) owner to postgres;

